package com.example.java26.week3.rest.homework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentTeacherApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentTeacherApplication.class, args);
    }
}


//    INSERT INTO STUDENT (ID,NAME,AGE,ISEXIST) VALUES (1, 'Paul', 32, TRUE);